/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 * Author:  Dion
 * Created: 23-Mar-2017
 */

SET FOREIGN_KEY_CHECKs = 0;
DROP TABLE IF EXISTS words;
DROP TABLE IF EXISTS student;
DROP TABLE IF EXISTS instructor;
DROP TABLE IF EXISTS sysAdmin;
DROP TABLE IF EXISTS access;
DROP TABLE IF EXISTS results;
SET FOREIGN_KEY_CHECKs = 1;
